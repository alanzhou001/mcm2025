library(tinytex)

pdflatex("mcmthesis-demo.tex", bib_engine = "biber")
